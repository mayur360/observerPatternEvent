package com.evnthandling.app.eventhandler;

import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

@Component
public class EventPublisher implements Sink {

	@EventListener
	public void publishHash(long id, byte[] message, byte[] salt, byte[] hash) {
		

	}

}
