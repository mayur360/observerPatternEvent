package com.evnthandling.app.event;

import com.evnthandling.app.publisher.ObserverPublisher;

public interface Source {

	void subscribe(ObserverPublisher observer);
	
}
