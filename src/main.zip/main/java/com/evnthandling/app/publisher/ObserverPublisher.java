/**
 * 
 */
package com.evnthandling.app.publisher;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Component;

import com.evnthandling.app.event.SubscribeEvent;

/**
 * @author marah
 *
 */
@Component
public class ObserverPublisher implements Observer {

	private static final Logger LOGGER = LogManager.getLogger(ObserverPublisher.class);
	
	@Autowired
	private ApplicationEventPublisher aep;
	
	@Override
	public void onSalt(byte[] salt) {
		LOGGER.info("******* onSalt **********");

	}

	@Override
	public void onMessage(long id, byte[] message) {
		LOGGER.info("******* onMessage **********");
		
	}
	
	public void callPublishHash(long id, byte[] message, byte[] salt, byte[] hash) {
		aep.publishEvent(new SubscribeEvent(this));
	}

}
